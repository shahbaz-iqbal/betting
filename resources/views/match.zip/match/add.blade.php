@extends('layout.app')
@section('content')
<div id="app">
    <match-add></match-add>
</div>
<script src="{{url('js/app.js')}}"></script>
@endsection
